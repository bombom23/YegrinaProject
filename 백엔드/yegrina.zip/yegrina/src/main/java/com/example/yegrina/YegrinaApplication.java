package com.example.yegrina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YegrinaApplication {

	public static void main(String[] args) {
		SpringApplication.run(YegrinaApplication.class, args);
	}

}
